//
//  MVBaseViewController.h
//  MerchantVersion
//
//  Created by 寜小陌 on 2018/1/17.
//  Copyright © 2018年 寜小陌. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MVBaseViewController : UIViewController

@end
