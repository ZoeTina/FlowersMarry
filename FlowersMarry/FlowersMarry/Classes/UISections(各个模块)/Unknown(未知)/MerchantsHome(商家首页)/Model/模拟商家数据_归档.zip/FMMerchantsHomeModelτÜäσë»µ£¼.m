//
//  FMMerchantsHomeModel.m
//  FlowersMarry
//
//  Created by 宁小陌 on 2018/7/3.
//  Copyright © 2018年 宁小陌. All rights reserved.
//

#import "FMMerchantsHomeModel.h"

@implementation FMMerchantsHomeModel
//+ (NSDictionary *)objectClassInArray
//{
//    return @{ @"subcategories": @"SubCategoryModel"};
//}

+ (NSDictionary *)objectClassInArray{
    return @{
             @"addr" : [AddressModel class],
             @"banner" : [BannerModel class],
             @"combination" : [CombinationModel class],
             @"exhibits" : [ExhibitsModel class],
             @"comments" : [CommentsModel class],
             @"discount" : [DiscountModel class],
             @"dynamic" : [DynamicModel class],
             };
}

@end

@implementation AddressModel

@end

@implementation BannerModel

@end

@implementation DiscountModel

@end

@implementation CombinationModel
+ (NSDictionary *)objectClassInArray{
    return @{@"list" : [CombinationListModel class]};
}
@end

@implementation CombinationListModel

@end

@implementation ExhibitsModel
+ (NSDictionary *)objectClassInArray{
    return @{@"list" : [ExhibitsListModel class]};
}
@end

@implementation ExhibitsListModel

@end


@implementation StoreLiveModel
+ (NSDictionary *)objectClassInArray{
    return @{@"list" : [StoreLiveListModel class]};
}
@end

@implementation StoreLiveListModel


@end

@implementation CommentsModel
+ (NSDictionary *)objectClassInArray{
    return @{@"list" : [CommentsListModel class]};
}
@end

@implementation CommentsListModel

@end
@implementation DynamicModel
+ (NSDictionary *)objectClassInArray{
    return @{@"list" : [DynamicListModel class]};
}
@end

@implementation DynamicListModel

@end
