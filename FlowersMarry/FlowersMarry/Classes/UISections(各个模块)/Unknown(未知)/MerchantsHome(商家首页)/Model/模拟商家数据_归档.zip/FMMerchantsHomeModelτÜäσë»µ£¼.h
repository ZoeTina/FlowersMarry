//
//  FMMerchantsHomeModel.h
//  FlowersMarry
//
//  Created by 宁小陌 on 2018/7/3.
//  Copyright © 2018年 宁小陌. All rights reserved.
//

#import <Foundation/Foundation.h>

@class AddressModel,BannerModel,DiscountModel,
        CombinationModel,CombinationListModel,
        ExhibitsModel,ExhibitsListModel,
        StoreLiveModel,StoreLiveListModel,
        CommentsModel,CommentsListModel,
        DynamicModel,DynamicListModel;
@interface FMMerchantsHomeModel : NSObject

/// 影楼名称
@property (nonatomic, copy) NSString *name;
@property (nonatomic, copy) NSString *bannerText;
@property (nonatomic, copy) NSString *url;
@property (nonatomic, copy) NSString *page;
@property (nonatomic, assign) BOOL isNonProfit;
/// 地址
@property (nonatomic, copy) NSString *address;
/// 多个标签
@property (nonatomic, copy) NSArray *links;
@property (nonatomic, strong) NSMutableArray<AddressModel *> *addr;
/// Banner 图
@property (nonatomic, strong) NSMutableArray<BannerModel *> *banner;
/// 优惠折扣栏
@property (nonatomic, strong) NSMutableArray<DiscountModel *> *discount;
/// 店铺实景
@property (nonatomic, strong) StoreLiveModel *storeLive;
/// 精品套餐
@property (nonatomic, strong) CombinationModel *combination;
/// 作品精选
@property (nonatomic, strong) ExhibitsModel *exhibits;
/// 网友点评
@property (nonatomic, strong) CommentsModel *comments;
/// 商家动态
@property (nonatomic, strong) DynamicModel *dynamic;


@end

@interface AddressModel : NSObject
/// 详细地址
@property (nonatomic, copy) NSString *address;
/// 街道
@property (nonatomic, copy) NSString *street;
/// 城市
@property (nonatomic, copy) NSString *city;
/// 省份
@property (nonatomic, copy) NSString *country;
@end

@interface BannerModel : NSObject
/// 文字内容
@property (nonatomic, copy) NSString *title;
/// 图片URL
@property (nonatomic, copy) NSString *url;
@end


/////////////// 优惠折扣栏 ///////////////
@interface DiscountModel : NSObject
/// 名称
@property (nonatomic, copy) NSString *name;
/// 类型
@property (nonatomic, assign) NSInteger type;
@end

/////////////// 精品套餐 ///////////////
@interface CombinationModel : NSObject
/// 类型名称
@property (nonatomic, copy) NSString *name;
/// 数量
@property (nonatomic, copy) NSString *count;
@property (nonatomic, strong) NSMutableArray<CombinationListModel *> *list;
@end

@interface CombinationListModel : NSObject
/// 标题
@property (nonatomic, copy) NSString *title;
/// 内容
@property (nonatomic, copy) NSString *content;
/// 图片URL
@property (nonatomic, copy) NSString *url;
/// 当前价格
@property (nonatomic, copy) NSString *price;
/// 原始价格
@property (nonatomic, copy) NSString *oldPrice;
/// 浏览量
@property (nonatomic, copy) NSString *browse;
@end

/////////////// 作品精选 ///////////////
@interface ExhibitsModel : NSObject
/// 类型名称
@property (nonatomic, copy) NSString *name;
/// 数量
@property (nonatomic, copy) NSString *count;
@property (nonatomic, strong) NSMutableArray<ExhibitsListModel *> *list;

@end

@interface ExhibitsListModel : NSObject
//// 标题
@property (nonatomic, copy) NSString *title;
/// 场景
@property (nonatomic, copy) NSString *scenario;
/// 风格
@property (nonatomic, copy) NSString *style;
/// 图片1
@property (nonatomic, copy) NSString *url;
/// 图片2
@property (nonatomic, copy) NSString *url1;
/// 图片3
@property (nonatomic, copy) NSString *url2;
/// 图片数量
@property (nonatomic, copy) NSString *count;
/// 浏览量
@property (nonatomic, copy) NSString *browse;
@end


/////////////// 店铺实景 ///////////////
@interface StoreLiveModel : NSObject
/// 类型名称
@property (nonatomic, copy) NSString *name;
@property (nonatomic, strong) NSMutableArray<StoreLiveListModel *> *list;

@end

@interface StoreLiveListModel : NSObject
/// 图片
@property (nonatomic, copy) NSString *url;

@end

/////////////// 网友点评 ///////////////
@interface CommentsModel : NSObject
/// 类型名称
@property (nonatomic, copy) NSString *name;
/// 数量
@property (nonatomic, copy) NSString *count;
@property (nonatomic, strong) NSMutableArray<CommentsListModel *> *list;
@end

@interface CommentsListModel : NSObject
/// 用户头像
@property (nonatomic, copy) NSString *avatar;
/// 标题
@property (nonatomic, copy) NSString *title;
/// 日期
@property (nonatomic, copy) NSString *date;
/// 内容
@property (nonatomic, copy) NSString *content;
/// 回复内容
@property (nonatomic, copy) NSString *replyContent;
/// 回复时间
@property (nonatomic, copy) NSString *replyTime;
/// 图片数组
@property (nonatomic, copy) NSArray *imageArray;

@end

/////////////// 商家动态 ///////////////
@interface DynamicModel : NSObject
/// 类型名称
@property (nonatomic, copy) NSString *name;
/// 数量
@property (nonatomic, copy) NSString *count;
@property (nonatomic, strong) NSMutableArray<DynamicListModel *> *list;

@end

@interface DynamicListModel : NSObject
/// 商家头像
@property (nonatomic, copy) NSString *avatar;
/// 标题
@property (nonatomic, copy) NSString *title;
/// 类型（0：视频，1：图片）
@property (nonatomic, copy) NSString *type;
/// 点赞量
@property (nonatomic, copy) NSString *like;
/// 商家昵称
@property (nonatomic, copy) NSString *nickname;
/// 发布时间
@property (nonatomic, copy) NSString *date;
/// 图片数组
@property (nonatomic, copy) NSArray *imageArray;

@end



















