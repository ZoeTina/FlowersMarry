//
//  FMMerchantsHomeViewController.m
//  FlowersMarry
//
//  Created by 宁小陌 on 2018/7/2.
//  Copyright © 2018年 宁小陌. All rights reserved.
//

#import "FMMerchantsHomeViewController.h"

/// 显示图片集
#import "FMShowPhotoCollectionViewController.h"
/// 图文详情
#import "FMPictureWithTextViewController.h"
/// 优惠
#import "FMMerchantsHomeTableViewCell.h"

#import "FMMerchantsHomeHeaderViewCell.h"
#import "FMMerchantsHomeAddressTableViewCell.h"

/// 套餐列表
#import "FMComboListTableViewCell.h"
/// 套餐详情
#import "FMComboListDetailsViewController.h"
/// 作品列表
#import "FMWorksListTableViewCell.h"
/// 作品详情页
#import "FMWorksListDetailsViewController.h"
/// 商家动态
#import "FMBusinessDynamicViewController.h"

/// 商铺信息Model
#import "FMMerchantsHomeModel.h"
/// 店铺实景Model
#import "FMStoreLiveModel.h"
/// 套餐列表Model
#import "FMCombinationModel.h"
/// 精选作品列表Model
#import "FMWorksListModel.h"
/// 活动Model
#import "FMActivityModel.h"

/// 动态类型的Cell
#import "FMVideoTableViewCell.h"
#import "FMImagesTableViewCell.h"
#import "FMMoreImagesTableViewCell.h"
#import "FMImagesRightTableViewCell.h"
#import "FMImagesTransverseThreeTableViewCell.h"


/// 电话预约
#import "FMTelephoneBookingViewController.h"
/// h活动详情
#import "FMActivityDetailsViewController.h"
/// 顶部滚动图
#import "FMMerchantsHomeHeaderView.h"
/// 店铺实景
#import "FMStoreLiveTableViewCell.h"
/// 底部工具条
#import "FMActivityDetailsFooterView.h"
/// 顶部透明
#import "FMHeaderNavigationTranspView.h"
/// 点评列表
#import "FMEvaluationListViewController.h"

/// 弹出消费保障
#import "FMConsumerProtectionViewController.h"
/// 作品精选
#import "FMWorksListViewController.h"
/// 精品套餐
#import "FMComboListViewController.h"
/// 点评 
#import "FMEvaluationModel.h"
#import "FMEvaluationTemplateOneTableViewCell.h"
#import "FMEvaluationTemplateTwoTableViewCell.h"
#import "FMEvaluationTemplateThreeTableViewCell.h"
#import "FMEvaluationTemplateFourTableViewCell.h"

/// 空数据cell
#import "SCEmptyDataTableViewCell.h"

/// 点评
static NSString * const reuseIdentifierOne = @"FMEvaluationTemplateOneTableViewCell";
static NSString * const reuseIdentifierTwo = @"FMEvaluationTemplateTwoTableViewCell";
static NSString * const reuseIdentifierThree = @"FMEvaluationTemplateThreeTableViewCell";
static NSString * const reuseIdentifierFour = @"FMEvaluationTemplateFourTableViewCell";

static NSString * const reuseIdentifier = @"FMMerchantsHomeTableViewCell";
static NSString * const reuseIdentifierHeaderView = @"FMMerchantsHomeHeaderView";
static NSString * const reuseIdentifierHeaderCell = @"FMMerchantsHomeHeaderCell";
static NSString * const reuseIdentifierCombination = @"FMComboListTableViewCell";
static NSString * const reuseIdentifierWorksList = @"FMWorksListTableViewCell";
static NSString * const reuseIdentifierAddress = @"FMMerchantsHomeAddressTableViewCell";
static NSString * const reuseIdentifierSectionHeaderView = @"SCTableViewSectionHeaderView";
static NSString * const reuseIdentifierSectionFooterView = @"SCTableViewSectionFooterView";

/// 空数据cell
static NSString * const reuseIdentifierEmptyData = @"SCEmptyDataTableViewCell";

/// 动态
static NSString * const reuseIdentifierVideo = @"FMVideoTableViewCell";
static NSString * const reuseIdentifierImage = @"FMImagesTableViewCell";
static NSString * const reuseIdentifierMoreImage = @"FMMoreImagesTableViewCell";
static NSString * const reuseIdentifierRightImage = @"FMImagesRightTableViewCell";
static NSString * const reuseIdentifierThreeImage = @"FMImagesTransverseThreeTableViewCell";
/// 实景
static NSString * const reuseIdentifierStoreLive = @"FMStoreLiveTableViewCell";

#define kHeaderHeight 250
@interface FMMerchantsHomeViewController ()<UITableViewDelegate,UITableViewDataSource,FMStoreLiveTableViewCellDelegate,FMMerchantsHomeHeaderViewCellDelegate>
@property (nonatomic, strong) UITableView *tableView;

//// 礼包和劵的数组
@property (nonatomic, strong) NSMutableArray *itemModelArray;
//// 整个TableView有多少组
@property (nonatomic, strong) NSMutableArray *sectionArray;

@property (nonatomic, strong) BusinessModel *businessModel;
@property (nonatomic, strong) FMActivityDetailsFooterView *footerView;
@property (nonatomic, strong) FMHeaderNavigationTranspView *headerView;



/// 底部工具栏
@property (nonatomic, strong) UIView *bottomView;
/// 顶部试图
@property (nonatomic, strong) UIView *headerNavigationView;

@property (nonatomic, strong) StoreLiveModel *storeLiveListModel;
@property (nonatomic, strong) CombinationDataModel *combinationDataModel;
@property (nonatomic, strong) WorksDataModel *worksListModel;
@property (nonatomic, strong) NSMutableArray *activityArray;

/// 点评列表
@property (nonatomic, strong) EvaluationDataModel *evaluationListModel;
/// 商家动态
@property (nonatomic, strong) HomePageDataModel *businessDynamicModel;

@property (nonatomic,strong) dispatch_group_t disGroup;
@end

@implementation FMMerchantsHomeViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [self initView];
    [self getBasicDataRequest];
    [self loadMoreRequest];
    [self.view showLoadingViewWithText:@"加载中..."];
}

- (void)viewWillAppear:(BOOL)animated{
    self.view.backgroundColor = kWhiteColor;
    [super viewWillAppear:animated];
    self.navigationController.navigationBar.hidden = YES;
}

- (void)setBusinessListModel:(BusinessListModel *)businessListModel{
    _businessListModel = businessListModel;
    self.title = _businessListModel.cp_fullname;
    
    YouhuiModel *youhui = businessListModel.youhui;
    if (youhui.gift.length != 0) {
        
        NSDictionary *dic = @{@"title": youhui.gift,
                              @"thumb": @"",
                              @"start_date": @"",
                              @"end_date": @"",
                              @"num": @0,
                              @"send_num": @0};
        [self.itemModelArray addObject: dic];
    }
    
    if (youhui.coupon.send_num != 0) {
        [self.itemModelArray addObject: youhui.coupon];
    }
}

/// 异步获取多个接口
- (void) getBasicDataRequest{
    //信号量
    //创建全局并行
    self.disGroup = dispatch_group_create();
    dispatch_queue_t mainqueue = dispatch_get_main_queue();
    
    dispatch_queue_t queue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0);
    dispatch_group_enter(self.disGroup);
    dispatch_group_enter(self.disGroup);
    //网络请求一
    dispatch_group_async(self.disGroup, queue, ^{
        [self loadActivityInfoData];
    });
    //网络请求二
    dispatch_group_async(self.disGroup, queue, ^{
        [self loadBusinesInfoData];
    });
    dispatch_group_notify(self.disGroup, mainqueue, ^{
        [self.tableView reloadData];
        self.tableView.hidden = NO;
        [self.view dismissLoadingView];
    });
}

#pragma mark --- 获取活动数据 ---
- (void) loadActivityInfoData{
    //// 商家活动数据
    NSDictionary *parameter = @{@"cp_id":self.businessListModel.cp_id};
    [SCHttpTools getWithURLString:@"huodong/getlist" parameter:parameter success:^(id responseObject) {
        if (responseObject) {
            FMActivityModel *model = [FMActivityModel mj_objectWithKeyValues:responseObject];
            self.activityArray = model.data.list;
            dispatch_group_leave(self.disGroup);
        }
    } failure:^(NSError *error) {
        YYLog(@"---- %@",error);
        [self.tableView.mj_header endRefreshing];
    }];
}

- (void) loadBusinesInfoData{
    //// 商家信息
    NSDictionary *parameter = @{@"id":self.businessListModel.cp_id};
    [SCHttpTools getWithURLString:@"company/getinfo" parameter:parameter success:^(id responseObject) {
        if (responseObject) {
            FMMerchantsHomeModel *model = [FMMerchantsHomeModel mj_objectWithKeyValues:responseObject];
            self.businessModel = model.data;
            dispatch_group_leave(self.disGroup);
        }
    } failure:^(NSError *error) {
        YYLog(@"---- %@",error);
        [self.tableView.mj_header endRefreshing];
    }];
}


- (void) loadMoreRequest{
    
    NSMutableDictionary *parameter = [[NSMutableDictionary alloc] init];
    [parameter setValue:kUserInfo.site_id forKey:@"site_id"];
    [parameter setValue:self.businessListModel.channel_id forKey:@"channel_id"];
    [parameter setValue:self.businessListModel.class_id forKey:@"class_d"];
    [parameter setValue:self.businessListModel.cp_id forKey:@"cp_id"];
    
    [self loadCombinationModel:parameter];
    [self loadWorksListModel:parameter];
    [self loadStoreLiveData:parameter];
    [self loadEvaluationModel:parameter];
    [self loadBusinessdDynamicModel:parameter];
}

///// 获取店铺实景数据
//- (void) loadStoreLiveData:(NSMutableDictionary *)parameter{
//    [SCHttpTools getWithURLString:@"shijing/getlist" parameter:parameter success:^(id responseObject) {
//        if (responseObject) {
//            FMStoreLiveModel *model = [FMStoreLiveModel mj_objectWithKeyValues:responseObject];
//            self.storeLiveListModel = model.data;
//            [self.tableView reloadData];
//        }
//    } failure:^(NSError *error) {
//        YYLog(@"获取店铺实景数据---- %@",error);
//        [self.tableView.mj_header endRefreshing];
//    }];
//}

/// 获取精品套餐数据
- (void) loadCombinationModel:(NSMutableDictionary *)parameter{
    [parameter setValue:@(3) forKey:@"size"];
    [parameter setValue:@(1) forKey:@"p"];
    [SCHttpTools getWithURLString:@"taoxi/getlist" parameter:parameter success:^(id responseObject) {
        if (responseObject) {
            FMCombinationModel *model = [FMCombinationModel mj_objectWithKeyValues:responseObject];
            self.combinationDataModel = model.data;
            [self.tableView reloadData];
            [self.tableView.mj_header endRefreshing];
        }
    } failure:^(NSError *error) {
        YYLog(@"获取精品套餐数据---- %@",error);
        [self.tableView.mj_header endRefreshing];
    }];
}

/// 获取作品列表数据
- (void) loadWorksListModel:(NSMutableDictionary *)parameter{
    [parameter setValue:@(3) forKey:@"size"];
    [parameter setValue:@(1) forKey:@"p"];
    [SCHttpTools getWithURLString:@"zuo_pin/getlist" parameter:parameter success:^(id responseObject) {
        if (responseObject) {
            FMWorksListModel *model = [FMWorksListModel mj_objectWithKeyValues:responseObject];
            self.worksListModel = model.data;
            [self.tableView reloadData];
            [self.tableView.mj_header endRefreshing];
        }
    } failure:^(NSError *error) {
        YYLog(@"获取作品列表数据---- %@",error);
        [self.tableView.mj_header endRefreshing];
    }];
}

/// 获取点评数据
- (void) loadEvaluationModel:(NSMutableDictionary *)parameter{
    [parameter setValue:@(3) forKey:@"size"];
    [parameter setValue:@(1) forKey:@"p"];
    [SCHttpTools getWithURLString:@"comment/getlist" parameter:parameter success:^(id responseObject) {
        NSDictionary *result = responseObject;
        if (result) {
            FMEvaluationModel *model = [FMEvaluationModel mj_objectWithKeyValues:result];
            self.evaluationListModel = model.data;
        }
        [self.tableView reloadData];
    } failure:^(NSError *error) {
        YYLog(@"---- %@",error);
    }];
}

/// 获取商家的动态数据
- (void) loadBusinessdDynamicModel:(NSMutableDictionary *)parameter{
    [parameter removeAllObjects];
    [parameter setValue:kUserInfo.site_id forKey:@"site_id"];
    [parameter setValue:self.businessListModel.cp_id forKey:@"cp_id"];
    [parameter setValue:@(3) forKey:@"size"];
    [parameter setValue:@(1) forKey:@"p"];
    [SCHttpTools getWithURLString:@"feed/getlist" parameter:parameter success:^(id responseObject) {
        NSDictionary *result = responseObject;
        if ([result isKindOfClass:[NSDictionary class]]) {
            FMHomePageModel *model = [FMHomePageModel mj_objectWithKeyValues:result];
            if (model.errcode == 0) {
                self.businessDynamicModel = model.data;
            }else {
                Toast([result lz_objectForKey:@"message"]);
            }
        }
        [self.tableView reloadData];
    } failure:^(NSError *error) {
        YYLog(@" -- error -- %@",error);
    }];
}

- (void) handleButtonEvents:(NSInteger) idx{
    /// idx ? 100:客服 101:关注 102:评论 103:免费预约 104:返回按钮 105:分享
    switch (idx) {
        case 100:
            [self lz_make:@"客服"];
            break;
        case 101:
            [self.footerView didClickGuanZhu:self.businessListModel.cp_id];
            break;
        case 102:
            
            break;
        case 103:
        {
            FMTelephoneBookingViewController *vc = [FMTelephoneBookingViewController new];
            [self sc_bottomPresentController:vc presentedHeight:287 completeHandle:^(BOOL presented) {
                if (presented) {
                    YYLog(@"弹出了");
                }else{
                    YYLog(@"消失了");
                }
            }];
        }
        case 104:
            [self.navigationController popViewControllerAnimated:YES];
            break;
        case 105:
            [self lz_make:@"分享"];
            break;
        default:
            break;
    }
}

- (void) jumpActivityDetailsController:(NSInteger) idx{
    ActivityListModel *model = self.activityArray[idx];

    FMActivityDetailsViewController *vc = [[FMActivityDetailsViewController alloc] initBusinessData:self.businessListModel
                                                                                              hd_id:model.hd_id];
    [self.navigationController pushViewController:vc animated:YES];
}

#pragma mark - Table view data sourceFMMerchantsHomeAddressTableViewCell
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    MV(weakSelf)
    
    if (indexPath.section==0) {
        if (indexPath.row==0) {
            FMMerchantsHomeHeaderView  *tools = [tableView dequeueReusableCellWithIdentifier:reuseIdentifierHeaderView forIndexPath:indexPath];
            tools.listMode = self.activityArray;
            [tools setImagesTemmpletCellCallBlock:^(NSInteger idx) {
                [weakSelf jumpActivityDetailsController:idx];
            }];
            return tools;
        }else if (indexPath.row==1) {
            FMMerchantsHomeHeaderViewCell *tools = [tableView dequeueReusableCellWithIdentifier:reuseIdentifierHeaderCell forIndexPath:indexPath];
            tools.delegate = self;
            tools.model = self.businessModel;
            return tools;
        }else{
            FMMerchantsHomeAddressTableViewCell *tools = [tableView dequeueReusableCellWithIdentifier:reuseIdentifierAddress forIndexPath:indexPath];
            tools.titleLabel.text = self.businessModel.cp_address;
            return tools;
        }
    }else if(indexPath.section==1){
        YouhuiModel *youhui = self.businessListModel.youhui;
        FMMerchantsHomeTableViewCell* tools = [tableView dequeueReusableCellWithIdentifier:reuseIdentifier forIndexPath:indexPath];
        if (indexPath.row==0) {
            tools.lineView.hidden = YES;
            if (youhui.coupon.send_num != 0) {
                tools.imagesView.image = kGetImage(@"base_merchant_coupon");
                tools.titleLabel.text = youhui.coupon.title;
            }else{
                tools.titleLabel.text = youhui.gift;
                tools.imagesView.image = kGetImage(@"base_merchant_gift");
            }
        }else{
            if (youhui.gift.length != 0) {
                tools.titleLabel.text = youhui.gift;
                tools.imagesView.image = kGetImage(@"base_merchant_gift");
            }
        }
        return tools;
    }else{
        if (indexPath.section==2) { /// 套餐
            FMComboListTableViewCell *tools = [tableView dequeueReusableCellWithIdentifier:reuseIdentifierCombination forIndexPath:indexPath];
            CombinationListModel *listModel = self.combinationDataModel.list[indexPath.row];
            tools.listModel = (CombinationDetailsModel *)listModel;
            if (indexPath.row != 0) {
                tools.linerViewCell.hidden = NO;
            }
            return tools;
        }else if(indexPath.section==3){ /// 作品
            FMWorksListTableViewCell *tools = [tableView dequeueReusableCellWithIdentifier:reuseIdentifierWorksList forIndexPath:indexPath];
            tools.listModel = self.worksListModel.list[indexPath.row];
            return tools;
        }else if(indexPath.section==4){ /// 店铺实景
            FMStoreLiveTableViewCell *tools = [tableView dequeueReusableCellWithIdentifier:reuseIdentifierStoreLive forIndexPath:indexPath];
            tools.delegate = self;
            tools.listModel = self.storeLiveListModel.list;
            return tools;
        }else if(indexPath.section==5){ /// 评论
            /// 0:评论 1:评论+回复 2:评论+图片 3:评论+图片+回复
            EvaluationModel *evaluationModel = self.evaluationListModel.list[indexPath.row];
            if (evaluationModel.ct_re_content.length>0 && evaluationModel.photo.count==0) {/// 评论+回复
                FMEvaluationTemplateFourTableViewCell* tools = [tableView dequeueReusableCellWithIdentifier:reuseIdentifierFour forIndexPath:indexPath];
                tools.model = evaluationModel;
                return tools;
            }else if (evaluationModel.photo.count>0 && evaluationModel.ct_re_content.length==0){/// 评论+图片
                FMEvaluationTemplateThreeTableViewCell* tools = [tableView dequeueReusableCellWithIdentifier:reuseIdentifierThree forIndexPath:indexPath];
                tools.model = evaluationModel;
                return tools;
            }else if (evaluationModel.ct_re_content.length>0&&evaluationModel.photo.count>0){/// 评论+图片+回复
                FMEvaluationTemplateTwoTableViewCell* tools = [tableView dequeueReusableCellWithIdentifier:reuseIdentifierTwo forIndexPath:indexPath];
                tools.model = evaluationModel;
                return tools;
            }else{  /// 纯文字
                FMEvaluationTemplateOneTableViewCell* tools = [tableView dequeueReusableCellWithIdentifier:reuseIdentifierOne forIndexPath:indexPath];
                tools.model = evaluationModel;
                return tools;
            }
        }else {
            if (self.businessDynamicModel.list.count>0) {
                HomePageListModel *model = self.businessDynamicModel.list[indexPath.row];
                switch (model.shape) {
                    case 1: {/// 图文
                        if (model.thumb_num==1) {/// 图文  ---  1:一张封面图
                            FMImagesRightTableViewCell* tools = [tableView dequeueReusableCellWithIdentifier:reuseIdentifierRightImage forIndexPath:indexPath];
                            tools.homeModel = model;
                            return tools;
                        }else{
                            FMImagesTransverseThreeTableViewCell* tools = [tableView dequeueReusableCellWithIdentifier:reuseIdentifierThreeImage forIndexPath:indexPath];
                            tools.homeModel = model;
                            return tools;
                        }
                    }
                        break;
                    case 2: {/// 图集  ---  1:一张封面图
                        if (model.thumb_num==1) {
                            FMImagesTableViewCell* tools = [tableView dequeueReusableCellWithIdentifier:reuseIdentifierImage forIndexPath:indexPath];
                            tools.homeModel = model;
                            return tools;
                        }else{
                            FMMoreImagesTableViewCell* tools = [tableView dequeueReusableCellWithIdentifier:reuseIdentifierMoreImage forIndexPath:indexPath];
                            tools.homeModel = model;
                            return tools;
                        }
                    }
                    case 3: {/// 视频
                        FMVideoTableViewCell* tools = [tableView dequeueReusableCellWithIdentifier:reuseIdentifierVideo forIndexPath:indexPath];
                        tools.homeModel = model;
                        return tools;
                    }
                }
            }else{
                SCEmptyDataTableViewCell* tools = [tableView dequeueReusableCellWithIdentifier:reuseIdentifierEmptyData forIndexPath:indexPath];
                return tools;
            }
            return [UITableViewCell new];
        }
    }
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.section==0&&indexPath.row==0) {
        if (self.activityArray.count>0) return IPHONE6_W(250);
    }else if (indexPath.section==0&&indexPath.row==1) {
        CGFloat height = self.businessModel.xblist.count==0?80:124;
        return height;
    }else if (indexPath.section==2) {
        return IPHONE6_W(132);
    }else if (indexPath.section==3){
        if (indexPath.row==2) return IPHONE6_W(310);
        return IPHONE6_W(297);
    }else if (indexPath.section==4){
        return IPHONE6_W(113);
    }else if (indexPath.section==6){
        if (self.businessDynamicModel.list.count==0) {
            return 400;
        }
    }
    return UITableViewAutomaticDimension;
}

// 多少个分组 section
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 7;
}

/// 返回多少
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    switch (section) {
        case 0:
            return 3;
            break;
        case 1:
            return self.itemModelArray.count;
            break;
        case 2:
            // 套餐
            return self.combinationDataModel.list.count;
            break;
        case 3:
            /// 作品
            return self.worksListModel.list.count;
            break;
        case 4:
            /// 店铺实景
            return 1;
            break;
        case 5:
            /// 评论
            return self.evaluationListModel.list.count;
            break;
        case 6:
            /// 动态
            return self.businessDynamicModel.list.count==0?1:self.businessDynamicModel.list.count;
            break;
        default:
            return 1;
            break;
    }
}

#pragma mark -------------- 设置Header高度 --------------
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    if (section==0||section==1) return 0.0f;
    return 44.0f;
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    if (section==6) return 0.1f;
    if (section==1 && (self.itemModelArray.count ==0)) return 0.1f;
    return 10.f;
}

#pragma mark -------------- 设置组头 --------------
- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section{
    if (section==0||section==1) {
        return nil;
    }
    MV(weakSelf)
    SCTableViewSectionHeaderView *headerView = [tableView dequeueReusableHeaderFooterViewWithIdentifier:reuseIdentifierSectionHeaderView];
    NSString *titleTextStr = @"";
    NSString *subtitleTestStr = @"";
    if (section==2) {
        titleTextStr = @"精品套餐";
        subtitleTestStr = [self setSubtitleValue:self.combinationDataModel.count unit:@"个"];
    }else if (section==3) {
        titleTextStr = @"作品精选";
        subtitleTestStr = [self setSubtitleValue:self.worksListModel.count unit:@"个"];
    }else if (section==4) {
        titleTextStr = @"店铺实景";
    }else if (section==5) {
        titleTextStr = @"网友点评";
        subtitleTestStr = [self setSubtitleValue:self.evaluationListModel.count unit:@"条"];
    }else if (section==6) {
        titleTextStr = @"商家动态";
        subtitleTestStr = [self setSubtitleValue:self.businessDynamicModel.totalCount unit:@"条"];
    }
    if (section==4) {
        headerView.arrowImageView.hidden = YES;
    }else{
        headerView.arrowImageView.hidden = NO;
    }
    headerView.titleLabel.text = titleTextStr;
    headerView.subtitleLabel.text = subtitleTestStr;
    
    [headerView.sectionButton lz_handleControlEvent:UIControlEventTouchUpInside withBlock:^{
        [weakSelf jumpViewController:section];
    }];
    
    return headerView;
}

- (void) jumpViewController:(NSInteger) idx{
    if (idx==2) {
        FMComboListViewController *vc = [[FMComboListViewController alloc] initBusinessModel:self.businessListModel];
        vc.listModel = self.combinationDataModel.list;
        [self.navigationController pushViewController:vc animated:YES];
    }else if(idx==3){
        FMWorksListViewController *vc = [[FMWorksListViewController alloc] initBusinessModel:self.businessListModel];
        vc.listModel = self.worksListModel.list;
        [self.navigationController pushViewController:vc animated:YES];
    }else if(idx==5){
        FMEvaluationListViewController *vc = [[FMEvaluationListViewController alloc] initBusinessData:self.businessListModel];
        [self.navigationController pushViewController:vc animated:YES];
    }else if(idx==6){
        FMBusinessDynamicViewController *vc = [[FMBusinessDynamicViewController alloc] initBusinessData:self.businessListModel];
        [self.navigationController pushViewController:vc animated:YES];
    }
}


- (NSString *) setSubtitleValue:(NSInteger )count unit:(NSString *)unit{
    return [NSString stringWithFormat:@"共%ld%@",(long)count,unit];
}

// UITableView在Plain类型下，HeaderView和FooterView不悬浮和不停留的方法
- (UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section {
    return [UIView lz_viewWithColor:kTableViewInSectionColor];
}

#pragma mark -------------- 当前列表Cell点击 --------------
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    BusinessListModel *businessModel = self.businessListModel;
    if(indexPath.section==2){
        CombinationListModel *listModel = self.combinationDataModel.list[indexPath.row];
        FMComboListDetailsViewController *vc = [[FMComboListDetailsViewController alloc] initBusinessModel:businessModel
                                                                                               Combination:listModel.tx_id];
        [self.navigationController pushViewController:vc animated:YES];
    }else if (indexPath.section==3) {
        WorksListModel *listModel = self.worksListModel.list[indexPath.row];
        FMWorksListDetailsViewController *vc = [[FMWorksListDetailsViewController alloc] initBusinessModel:businessModel
                                                                                                   Case_id:listModel.case_id];
        [self.navigationController pushViewController:vc animated:YES];
    }else if(indexPath.section==6){
        HomePageListModel *model = self.businessDynamicModel.list[indexPath.row];
        switch (model.shape) {
            case 1:/// 图文
            {
                FMPictureWithTextViewController *vc = [[FMPictureWithTextViewController alloc] initHomeDataModel:model];
                vc.hidesBottomBarWhenPushed = YES;
                [self.navigationController pushViewController:vc animated:YES];
            }
                break;
            case 2:/// 图集
            {
                FMShowPhotoCollectionViewController *vc = [[FMShowPhotoCollectionViewController alloc] initHomeDataModel:model];
                vc.hidesBottomBarWhenPushed = YES;
                [self.navigationController pushViewController:vc animated:YES];
            }
                break;
            case 3:/// 视频
                
                break;
        }
    }
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
}

//点击UICollectionViewCell的代理方法
#pragma mark -------------- 网友点评图片点击 --------------
- (void)didSelectItemAtIndexPath:(NSIndexPath *)indexPath withContent:(NSString *)content {
    [self lz_make:[NSString stringWithFormat:@"网友点评第 %ld 张图片",indexPath.row]];
}

#pragma mark -------------- 店铺实景点击事件 --------------
- (void)didSelectStoreLiveItemAtIndexPath:(NSIndexPath *)indexPath withContent:(NSString *)content {
    YYLog(@"店铺实景点击事件 --- %ld",indexPath.row);
    [self lz_make:[NSString stringWithFormat:@"店铺实景第 %ld 张图片",indexPath.row]];
}

#pragma mark -------------- 消费保障点击事件 --------------
- (void)didSelectSecurityItemAtIndexPath:(NSIndexPath *)indexPath withContent:(NSString *)content {
    FMConsumerProtectionViewController *vc = [[FMConsumerProtectionViewController alloc] init];
    vc.xblist = self.businessModel.xblist;
    [self sc_bottomPresentController:vc presentedHeight:252 completeHandle:^(BOOL presented) {
        if (presented) {
            YYLog(@"弹出了");
        }else{
            YYLog(@"消失了");
        }
    }];
}


#pragma mark -------------- 设置约束  --------------
- (void) initView{

    [self.view addSubview:self.tableView];
    
    [self.view addSubview:self.headerNavigationView];
    [self.headerNavigationView addSubview:self.headerView];
    
    [self.view addSubview:self.bottomView];
    [self.bottomView addSubview:self.footerView];
    
    [self.headerNavigationView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.right.mas_equalTo(self.view);
        make.height.mas_equalTo(kNavBarHeight);
    }];
    
    [self.headerView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.right.bottom.mas_equalTo(self.headerNavigationView);
        make.height.mas_equalTo(kNavBarHeight-kSafeAreaBottomHeight);
    }];
    
    CGFloat bottomHeight= 50 + kSafeAreaBottomHeight;
    [self.bottomView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.right.bottom.mas_equalTo(self.view);
        make.height.mas_equalTo(bottomHeight);
    }];
    [self.tableView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.left.right.equalTo(self.view);
        make.bottom.mas_equalTo(self.bottomView.mas_top);
    }];
    
    [self.footerView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.right.left.mas_equalTo(self.bottomView);
        make.height.mas_equalTo(bottomHeight-kSafeAreaBottomHeight);
    }];
}

#pragma mark -------------- 懒加载 --------------
-(UITableView *)tableView{
    if (!_tableView) {
        _tableView = [[UITableView alloc] initWithFrame:CGRectZero style:UITableViewStyleGrouped];
        _tableView.showsVerticalScrollIndicator = false;
        // 拖动tableView时收起键盘
        _tableView.keyboardDismissMode = UIScrollViewKeyboardDismissModeOnDrag;
        _tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
        [_tableView registerClass:[SCTableViewSectionHeaderView class] forHeaderFooterViewReuseIdentifier:reuseIdentifierSectionHeaderView];
        [_tableView registerClass:[SCTableViewSectionFooterView class] forHeaderFooterViewReuseIdentifier:reuseIdentifierSectionFooterView];
        
        [_tableView registerClass:[FMMerchantsHomeTableViewCell class] forCellReuseIdentifier:reuseIdentifier];
        [_tableView registerClass:[FMMerchantsHomeHeaderView class] forCellReuseIdentifier:reuseIdentifierHeaderView];
        [_tableView registerClass:[FMMerchantsHomeAddressTableViewCell class] forCellReuseIdentifier:reuseIdentifierAddress];
        [_tableView registerClass:[FMMerchantsHomeHeaderViewCell class] forCellReuseIdentifier:reuseIdentifierHeaderCell];
        [_tableView setSeparatorInset:UIEdgeInsetsMake(0, 0, 0, 0)];
        /// 套餐
        [_tableView registerClass:[FMComboListTableViewCell class] forCellReuseIdentifier:reuseIdentifierCombination];
        /// 作品
        [_tableView registerClass:[FMWorksListTableViewCell class] forCellReuseIdentifier:reuseIdentifierWorksList];

        /// 商家动态
        [_tableView registerClass:[FMVideoTableViewCell class] forCellReuseIdentifier:reuseIdentifierVideo];
        [_tableView registerClass:[FMImagesTableViewCell class] forCellReuseIdentifier:reuseIdentifierImage];
        [_tableView registerClass:[FMMoreImagesTableViewCell class] forCellReuseIdentifier:reuseIdentifierMoreImage];
        [_tableView registerClass:[FMImagesRightTableViewCell class] forCellReuseIdentifier:reuseIdentifierRightImage];
        [_tableView registerClass:[FMImagesTransverseThreeTableViewCell class] forCellReuseIdentifier:reuseIdentifierThreeImage];
        /// 店铺实景
        [_tableView registerClass:[FMStoreLiveTableViewCell class] forCellReuseIdentifier:reuseIdentifierStoreLive];
        
        /// 点评
        [_tableView registerClass:[FMEvaluationTemplateOneTableViewCell class] forCellReuseIdentifier:reuseIdentifierOne];
        [_tableView registerClass:[FMEvaluationTemplateTwoTableViewCell class] forCellReuseIdentifier:reuseIdentifierTwo];
        [_tableView registerClass:[FMEvaluationTemplateThreeTableViewCell class] forCellReuseIdentifier:reuseIdentifierThree];
        [_tableView registerClass:[FMEvaluationTemplateFourTableViewCell class] forCellReuseIdentifier:reuseIdentifierFour];
        
        /// 空数据Cell
        [_tableView registerClass:[SCEmptyDataTableViewCell class] forCellReuseIdentifier:reuseIdentifierEmptyData];
        _tableView.hidden = YES;
        //1 禁用系统自带的分割线
        //        _tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
        _tableView.delegate = self;
        _tableView.dataSource = self;
        _tableView.backgroundColor = kViewColorNormal;
        _tableView.rowHeight = UITableViewAutomaticDimension;
    }
    return _tableView;
}

- (NSMutableArray *)itemModelArray{
    if (!_itemModelArray) {
        _itemModelArray = [[NSMutableArray alloc] init];
    }
    return _itemModelArray;
}

- (NSMutableArray *)activityArray{
    if (!_activityArray) {
        _activityArray = [[NSMutableArray alloc] init];
    }
    return _activityArray;
}

- (NSMutableArray *)sectionArray{
    if (!_sectionArray) {
        NSArray *arr2=@[@"one",@"three",@"four",@"five",@"six",@"seven"];
        _sectionArray = [NSMutableArray arrayWithArray:arr2];
    }
    return _sectionArray;
}

- (UIView *)bottomView{
    if (!_bottomView) {
        _bottomView = [UIView lz_viewWithColor:kWhiteColor];
    }
    return _bottomView;
}

- (FMActivityDetailsFooterView *)footerView{
    if (!_footerView) {
        _footerView = [[FMActivityDetailsFooterView alloc] init];
        [_footerView.shangpuButton setTitle:@"评论" forState:UIControlStateNormal];
        [_footerView.shangpuButton setImage:kGetImage(@"live_btn_pinglun") forState:UIControlStateNormal];
        MV(weakSelf)
        _footerView.block = ^(NSInteger idx) {
            [weakSelf handleButtonEvents:idx];
        };
    }
    return _footerView;
}

- (UIView *)headerNavigationView{
    if (!_headerNavigationView) {
        _headerNavigationView = [UIView lz_viewWithColor:kClearColor];
    }
    return _headerNavigationView;
}

- (FMHeaderNavigationTranspView *)headerView{
    if (!_headerView) {
        _headerView = [[FMHeaderNavigationTranspView alloc] init];
        MV(weakSelf)
        _headerView.block = ^(NSInteger idx) {
            [weakSelf handleButtonEvents:idx];
        };
    }
    return _headerView;
}

- (UIStatusBarStyle)preferredStatusBarStyle {
    return UIStatusBarStyleLightContent;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



@end
