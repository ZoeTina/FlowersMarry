//
//  FMBusinessTableViewCell.m
//  FlowersMarry
//
//  Created by 宁小陌 on 2018/6/27.
//  Copyright © 2018年 宁小陌. All rights reserved.
//

#import "FMBusinessTableViewCell.h"

#import "SCStartRating.h"
#import "FMTravelCollectionViewCell.h"
#import "FMMineReviewModel.h"

static NSString * const reuseIdentifier = @"FMTravelCollectionViewCell";

@interface FMBusinessTableViewCell()<UICollectionViewDelegate,UICollectionViewDataSource>

@property (nonatomic,strong) UICollectionView * collectionView;

/// 记录最后的height
@property (nonatomic, assign) CGFloat endHeight;
@property (nonatomic, assign) NSInteger imagesCount;

@property (nonatomic, strong) SCStartRating *stratingView;

@end
@implementation FMBusinessTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        self.contentView.backgroundColor = [UIColor clearColor];
        [self initView];
    }
    return self;
}

- (void) initView{
    
    _imagesCount = [FMMineReviewModel getModelData].count;
    [self addSubview:self.titleLabel];
    [self addSubview:self.baoImagesView];
    [self addSubview:self.qiImagesView];
    [self addSubview:self.recommendedImagesView];
    [self addSubview:self.giftImagesView];
    [self addSubview:self.contentLabel];
    
    [self addSubview:self.areaLabel];
    [self addSubview:self.stratingView];
    [self addSubview:self.scoreLabel];
    
    [self addSubview:self.collectionView];
    MV(weakSelf)
    self.stratingView.currentScoreChangeBlock = ^(CGFloat score){
        weakSelf.scoreLabel.text = [NSString stringWithFormat:@"%.1f 星",score];
    };
    CGFloat idx = 2/3.0;
    YYLog(@"---- %d---- %d",(int)ceilf(0.33333333),(int)ceilf(idx));

    // 请在设置完成最大最小的分数后再设置当前分数
    self.stratingView.currentScore = 4.0f;
    /// 设置约束
    [self initConstraints];
}

#pragma mark ---- UICollectionViewDataSource
// MARK:- ====UICollectionViewDataSource,UICollectionViewDelegate=====
- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView {
    return 1;
}

//每个分区有多少个数据
- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    return 3;//_imagesCount;
}

- (__kindof UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    FMTravelCollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:reuseIdentifier forIndexPath:indexPath];
    cell.backgroundColor = kColorWithRGB(231, 242, 248);
    cell.containerView.hidden = NO;
    cell.linerView.hidden = YES;
    NSString *imagesUrl = [NSString stringWithFormat:@"%@",[FMMineReviewModel getModelData][indexPath.row]];
    cell.imagesView.image = kGetImage(imagesUrl);
    [self updateCollectionViewHeight:
     self.collectionView.collectionViewLayout.collectionViewContentSize.height];
    
    return cell;
}

/// 点击collectionViewCell
- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath {
    if (self.delegate && [self.delegate respondsToSelector:@selector(didSelectItemAtIndexPath:withContent:)]) {
        [self.delegate didSelectItemAtIndexPath:indexPath withContent:self.dataArray[indexPath.section][indexPath.row]];
    }
}

/// 更新CollectionViewHeight
- (void)updateCollectionViewHeight:(CGFloat)height {
    if (self.endHeight != height) {
        self.endHeight = height;
        if (_delegate && [_delegate respondsToSelector:@selector(updateTableViewCellHeight:andheight:andIndexPath:)]) {
            [self.delegate updateTableViewCellHeight:self andheight:height andIndexPath:self.indexPath];
        }
    }
}

//布局协议对应的方法实现
#pragma mark - UICollectionViewDelegateFlowLayout
//设置每个一个Item（cell）的大小
- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath{
    CGFloat item = 3;
    CGFloat spacing = 3.0*2;
    CGFloat margin = 15.0*2;
    CGFloat width = (kScreenWidth-IPHONE6_W(margin)-IPHONE6_W(spacing))/item;
    return CGSizeMake(width, width);
}

//设置所有的cell组成的视图与section 上、左、下、右的间隔
- (UIEdgeInsets)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout insetForSectionAtIndex:(NSInteger)section{
    
    return UIEdgeInsetsMake(0,0,0,0);
}


- (UICollectionView *)collectionView{
    if (!_collectionView) {
        UICollectionViewFlowLayout *flowLayout = [[UICollectionViewFlowLayout alloc] init];
        //确定滚动方向
        flowLayout.scrollDirection = UICollectionViewScrollDirectionVertical;
        //确定item的大小
        //        flowLayout.itemSize = CGSizeMake(100, 120);
        //确定横向间距(设置行间距)
        flowLayout.minimumLineSpacing = 3;
        //确定纵向间距(设置列间距)
        flowLayout.minimumInteritemSpacing = 0;
        //确定距离上左下右的距离
        flowLayout.sectionInset = UIEdgeInsetsMake(0, 0, 0, 0);
        //头尾部高度
        flowLayout.headerReferenceSize = CGSizeMake(0, 0);
        flowLayout.footerReferenceSize = CGSizeMake(0, 0);
        
        _collectionView = [[UICollectionView alloc] initWithFrame:CGRectZero collectionViewLayout:flowLayout];
        _collectionView.backgroundColor = [UIColor clearColor];
        [_collectionView registerClass:[FMTravelCollectionViewCell class] forCellWithReuseIdentifier:reuseIdentifier];
        _collectionView.delegate = self;
        _collectionView.dataSource = self;
        _collectionView.showsVerticalScrollIndicator = NO;
        _collectionView.showsHorizontalScrollIndicator = NO;
        _collectionView.bounces = YES;
    }
    return _collectionView;
}

- (void) initConstraints{
    
    CGFloat margin = 15.0;
    [self.titleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(IPHONE6_W(margin));
        make.right.mas_equalTo(self.mas_right).mas_offset(IPHONE6_W(-15));
        make.top.mas_equalTo(20);
        make.bottom.mas_equalTo(self.stratingView.mas_top).mas_offset(IPHONE6_W(-7));
    }];
    [self.areaLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.mas_equalTo(self.titleLabel);
        make.right.mas_equalTo(self.mas_right).mas_offset(IPHONE6_W(-margin));
    }];
    
    [self.stratingView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(IPHONE6_W(margin));
        make.width.mas_equalTo(IPHONE6_W(70));
        make.bottom.mas_equalTo(self.giftImagesView.mas_top).offset(IPHONE6_W(-7));
        make.height.mas_equalTo(14);
    }];
    
    [self.scoreLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(self.stratingView.mas_right).mas_offset(IPHONE6_W(7));
        make.centerY.mas_equalTo(self.stratingView);
    }];
    
    [self.baoImagesView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(self.scoreLabel.mas_right).offset(IPHONE6_W(7));
        make.centerY.mas_equalTo(self.scoreLabel);
    }];
    [self.qiImagesView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(self.baoImagesView.mas_right).offset(IPHONE6_W(3));
        make.centerY.mas_equalTo(self.scoreLabel);
    }];
    [self.recommendedImagesView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(self.qiImagesView.mas_right).offset(IPHONE6_W(3));
        make.centerY.mas_equalTo(self.scoreLabel);
    }];
    
    [self.giftImagesView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(IPHONE6_W(margin));
        make.bottom.equalTo(self.collectionView.mas_top).offset(IPHONE6_W(-10));
    }];
    [self.contentLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.giftImagesView.mas_right).offset(5);
        make.centerY.equalTo(self.giftImagesView);
    }];
    
    /// 进位法，得到有多少列
    //    YYLog(@"---- %d---- %d",(int)ceilf(0.33333333),(int)ceilf(idx));
    CGFloat item = 3;
    CGFloat spacing = 3.0*2;
    CGFloat margin_c = 15.0*2;
    CGFloat height = (kScreenWidth-IPHONE6_W(margin_c)-IPHONE6_W(spacing))/item;
    
    [self.collectionView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(IPHONE6_W(margin));
        make.right.mas_equalTo(self.mas_right).mas_offset(IPHONE6_W(-margin));
        make.height.mas_equalTo(height);
        make.bottom.mas_equalTo(self.mas_bottom).mas_offset(IPHONE6_W(-10));
    }];
}

- (UILabel *)titleLabel{
    if (!_titleLabel) {
        _titleLabel = [UILabel lz_labelWithTitle:@"" color:kTextColor51 font:kFontSizeScBold15];
    }
    return _titleLabel;
}

- (UIImageView *)baoImagesView{
    if (!_baoImagesView) {
        _baoImagesView = [[UIImageView alloc] init];
        _baoImagesView.image = kGetImage(@"business_bao");
    }
    return _baoImagesView;
}

- (UIImageView *)qiImagesView{
    if (!_qiImagesView) {
        _qiImagesView = [[UIImageView alloc] init];
        _qiImagesView.image = kGetImage(@"business_qi");
    }
    return _qiImagesView;
}

- (UIImageView *)recommendedImagesView{
    if (!_recommendedImagesView) {
        _recommendedImagesView = [[UIImageView alloc] init];
        _recommendedImagesView.image = kGetImage(@"business_tuijian");
    }
    return _recommendedImagesView;
}

- (UIImageView *)giftImagesView{
    if (!_giftImagesView) {
        _giftImagesView = [[UIImageView alloc] init];
        _giftImagesView.image = kGetImage(@"business_gift");
    }
    return _giftImagesView;
}

- (UILabel *)contentLabel{
    if (!_contentLabel) {
        _contentLabel = [UILabel lz_labelWithTitle:@"" color:kTextColor136 font:kFontSizeMedium12];
    }
    return _contentLabel;
}

- (UILabel *)scoreLabel{
    if (!_scoreLabel) {
        _scoreLabel = [UILabel lz_labelWithTitle:@"" color:kTextColor135 font:kFontSizeMedium11];
    }
    return _scoreLabel;
}

- (UILabel *)areaLabel{
    if (!_areaLabel) {
        _areaLabel = [UILabel lz_labelWithTitle:@"" color:kTextColor136 font:kFontSizeMedium12];
    }
    return _areaLabel;
}

- (SCStartRating *)stratingView{
    if (!_stratingView) {
        _stratingView = [[SCStartRating alloc] initWithFrame:CGRectMake(0, 0, 80, 0) Count:5];
        _stratingView.spacing = 5.0f;
        _stratingView.checkedImage = kGetImage(@"business_shixing");
        _stratingView.uncheckedImage = kGetImage(@"business_kongxing");
        _stratingView.type = SCRatingTypeHalf;
        _stratingView.touchEnabled = YES;
        _stratingView.slideEnabled = YES;
        _stratingView.maximumScore = 5.0f;
        _stratingView.minimumScore = 0.0f;
    }
    return _stratingView;
}

@end
